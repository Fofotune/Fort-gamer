import Link from 'next/link';

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24 bg-gray-900">
      <h1 className="text-4xl font-bold text-white mb-8">À la Recherche de Reçudie Baveno</h1>
      <Link 
        href="/game" 
        className="px-8 py-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
      >
        Start Game
      </Link>
    </main>
  );
}