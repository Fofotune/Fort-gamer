'use client';

import { Stage, Container, Sprite } from '@pixijs/react';
import { useEffect, useState } from 'react';

const GAME_WIDTH = 800;
const GAME_HEIGHT = 600;
const PLAYER_SPEED = 5;
const GRAVITY = 0.5;
const JUMP_FORCE = -10;

export default function Game() {
  const [playerPos, setPlayerPos] = useState({ x: 100, y: 300 });
  const [velocity, setVelocity] = useState({ x: 0, y: 0 });
  const [isGrounded, setIsGrounded] = useState(false);
  const [keys, setKeys] = useState(new Set());

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      setKeys(prev => new Set(prev).add(e.code));
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      setKeys(prev => {
        const newKeys = new Set(prev);
        newKeys.delete(e.code);
        return newKeys;
      });
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  useEffect(() => {
    const gameLoop = () => {
      setPlayerPos(pos => {
        let newX = pos.x;
        let newY = pos.y;
        let newVelX = 0;
        let newVelY = velocity.y;

        // Horizontal movement
        if (keys.has('ArrowLeft')) newVelX = -PLAYER_SPEED;
        if (keys.has('ArrowRight')) newVelX = PLAYER_SPEED;

        // Jumping
        if (keys.has('Space') && isGrounded) {
          newVelY = JUMP_FORCE;
          setIsGrounded(false);
        }

        // Apply gravity
        if (!isGrounded) {
          newVelY += GRAVITY;
        }

        // Update position
        newX += newVelX;
        newY += newVelY;

        // Ground collision
        if (newY > GAME_HEIGHT - 100) {
          newY = GAME_HEIGHT - 100;
          newVelY = 0;
          setIsGrounded(true);
        }

        // Update velocity
        setVelocity({ x: newVelX, y: newVelY });

        // Boundary checks
        newX = Math.max(0, Math.min(newX, GAME_WIDTH - 50));
        
        return { x: newX, y: newY };
      });
    };

    const gameInterval = setInterval(gameLoop, 1000 / 60);
    return () => clearInterval(gameInterval);
  }, [keys, velocity, isGrounded]);

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-900">
      <Stage width={GAME_WIDTH} height={GAME_HEIGHT} options={{ backgroundColor: 0x1099bb }}>
        <Container>
          {/* Temporary player rectangle */}
          <Sprite
            image="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyBAMAAADsEZWCAAAAG1BMVEVHcEz/////////////////////////////+/tg9G6wAAAACHRSTlMAGBAweKjY8Jn5CoEAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAA2SURBVDjLY2AYBaNg8AJGJQEkwMQoqIQkwqCkxIAGlJQYkQALIxJgYEICjEhAERkwDd2QGQUAAIlBBBRgH0pJAAAAAElFTkSuQmCC"
            x={playerPos.x}
            y={playerPos.y}
            width={50}
            height={50}
          />
          {/* Ground */}
          <Sprite
            image="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mM8w8DwHwAEOQHNmnaaOAAAAABJRU5ErkJggg=="
            y={GAME_HEIGHT - 50}
            width={GAME_WIDTH}
            height={50}
          />
        </Container>
      </Stage>
    </div>
  );
}